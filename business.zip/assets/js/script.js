
document.addEventListener("DOMContentLoaded", function () {

    const menuToggle = document.querySelector(".menu-toggle");
    const navigation = document.querySelector(".navigation");

    menuToggle.addEventListener("click", function () {
        navigation.classList.toggle("active");
    });

});

var backToTop = document.getElementById('backToTop');
if (backToTop) {
    backToTop.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}



$(document).ready(function () {
    $('.testimonials').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        dots: false,
        arrows: false,
        responsive: [
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                dots: true
            }
        }
    ]
    });
});


